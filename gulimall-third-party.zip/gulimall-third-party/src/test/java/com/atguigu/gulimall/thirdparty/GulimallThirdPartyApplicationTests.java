package com.atguigu.gulimall.thirdparty;

//import org.junit.jupiter.api.Test;
import com.aliyun.oss.OSSClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GulimallThirdPartyApplicationTests {

	@Test
	public void contextLoads() {
	}
	@Autowired
	OSSClient ossClient;
	@Test
	public void testUpload() throws FileNotFoundException {
		// yourEndpoint填写Bucket所在地域对应的Endpoint。以华东1（杭州）为例，Endpoint填写为https://oss-cn-hangzhou.aliyuncs.com。
//		String endpoint = "oss-cn-beijing.aliyuncs.com";
//		// 阿里云账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM用户进行API访问或日常运维，请登录RAM控制台创建RAM用户。
//		String accessKeyId = "LTAI5t6iiRoVog7UbCHjLQZA";
//		String accessKeySecret = "8kI6lz0kFSkzoo96tSTRLdzLJiEARW";

		// 创建OSSClient实例。
//		OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

		// 填写本地文件的完整路径。如果未指定本地路径，则默认从示例程序所属项目对应本地路径中上传文件流。
		InputStream inputStream = new FileInputStream("D:\\lishuai\\临时\\谷粒商城电商项目-2020-尚硅谷-雷丰阳\\01.分布式基础基础基础基础基础基础（全栈开发篇）\\资料源码\\docs\\pics\\6a1b2703a9ed8737.jpg");
		// 依次填写Bucket名称（例如examplebucket）和Object完整路径（例如exampledir/exampleobject.txt）。Object完整路径中不能包含Bucket名称。
		ossClient.putObject("gulimall-happylee", "haha.jpg", inputStream);

//		D:\\lishuai\\临时\\github笔记\\markdownblog\\谷粒商城\\images\\1587609877028.png

		// 关闭OSSClient。
		ossClient.shutdown();

		System.out.println("上传成功...");
	}

}
