package com.atguigu.gulimall.ware.vo;

import lombok.Data;

import java.util.List;

@Data
public class SkuHasStockVo {
    private Long skuId;

//    private List<Long> wareId;
//
//    private Integer num;
    private Boolean hasStock;


}
