package com.atguigu.gulimall.ware;

import org.junit.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GulimallWareApplicationTests {

	@Test
	public void contextLoads() {
	}

}
