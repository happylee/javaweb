package com.atguigu.gulimall.search.vo;

import lombok.Data;

@Data
public class BrandVo {
    private Long brandId;
    private String brandName;
}
