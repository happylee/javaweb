package com.atguigu.gulimall.product.vo;

import lombok.Data;

@Data
public class SkuHasStockVo {
    private Long skuId;

//    private List<Long> wareId;
//
//    private Integer num;
    private Boolean hasStock;


}
