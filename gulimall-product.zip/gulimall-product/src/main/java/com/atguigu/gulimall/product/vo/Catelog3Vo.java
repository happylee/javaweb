package com.atguigu.gulimall.product.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//三级分类vo
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Catelog3Vo {
    private String id;

    private String name;

    private String catalog2Id;//父分类，二级分类id
}
