package com.atguigu.gulimall.product.vo;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class SpuBaseAttrVo{
	private String attrName;

	private String attrValue;
}