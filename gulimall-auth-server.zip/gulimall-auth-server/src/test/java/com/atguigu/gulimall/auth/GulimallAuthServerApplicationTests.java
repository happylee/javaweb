package com.atguigu.gulimall.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallAuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
