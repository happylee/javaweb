package com.atguigu.gulimall.gateway;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GulimallGatewayApplicationTests {

	@Test
	public void contextLoads() {
	}

}
