package com.atguigu.gulimall.order;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GulimallOrderApplicationTests {

	@Test
	public void contextLoads() {
	}

}
