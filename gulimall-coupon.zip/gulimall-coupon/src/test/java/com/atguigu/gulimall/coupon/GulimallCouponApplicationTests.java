package com.atguigu.gulimall.coupon;

//import org.junit.jupiter.api.Test;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GulimallCouponApplicationTests {

	@Test
	public void contextLoads() {
	}

}
